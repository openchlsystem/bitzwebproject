<template>
  <div class="contact">
    <h1>This is a contact page</h1>
  </div>
</template>

<script>
export default {
  name: "ContactView ",
  components: {},
};
</script>
