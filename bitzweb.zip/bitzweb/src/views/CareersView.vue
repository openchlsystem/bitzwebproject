<template>
  <div class="careers">
    <h1>This is a career page</h1>
  </div>
</template>

<script>
export default {
  name: "CareersView ",
  components: {},
};
</script>
