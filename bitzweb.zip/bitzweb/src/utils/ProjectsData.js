export const ProjectsData = [
  {
    id: 0,
    name: "Project1",
    description:
      "We endevour to help our customer achieve their business goals through the use technology.",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 1,
    "name ": "Project2",
    description:
      "We endevour to help our customer achieve their business goals through the use technology.",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 2,
    name: "Project3",
    description:
      "We endevour to help our customer achieve their business goals through the use technology.",
    Image: "https://source.unsplash.com/random",
  },
];
