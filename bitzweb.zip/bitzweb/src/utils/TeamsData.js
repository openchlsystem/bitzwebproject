export const TeamsData = [
  {
    id: 0,
    title: "Title1",
    description: "CEO",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 1,
    title: "Title2",
    description: "Business Manager ",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 2,
    title: "Title3",
    description: " Developer ",
    Image: "https://source.unsplash.com/random",
  },
];
