export const MissionsData = [
  {
    id: 0,
    title: "About Us",
    description:
      "We are a team of passionate people whose goal is to improve everyone life through disruptive products. We build great products to solve your business problems",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 1,
    title: " Mission",
    description:
      "We endevour to help our customer achieve their business goals through the use technology.",
    Image: "https://source.unsplash.com/random",
  },
  {
    id: 2,
    title: "Vision",
    description:
      "Provide cost effective and reliable technology that will help our customers grow",
    Image: "https://www.w3schools.com/w3css/img_lights.jpg",
  },
];
